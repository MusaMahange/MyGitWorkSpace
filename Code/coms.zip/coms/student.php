<!DOCTYPE html>
<html>

<link rel="stylesheet" type="text/css" href="student.css">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
  <title>Record Managemment System</title>
</head>




<body>
  <div class="header" style="text-align:right;margin-top:0px;margin-right:20px">
       <h2><a href="index.html" style="text-decoration:none;color:white"> Logout</a></h2>
  </div>

<!-- Register user-->
<div class="content">


 <?php
      $servername = "localhost";
      $username = "f3844563_mushe";
      $password = "ITmudzanani1";
      $dbname = "f3844563_Employees";

             $conn = new mysqli($servername, $username, $password,$dbname);
               $sql = "SELECT Course_name From courses";

               $sqldata = mysqli_query($conn,$sql) or die('Error sql query');
               echo "<table>";

                    echo "<div style='margin-top:10%'></div>";
               while($row = mysqli_fetch_array($sqldata,MYSQLI_ASSOC)) {
                   echo "<tr>";
                     echo "<div id='align' align=center style='margin-top:20px;color:white'>";
                     echo "Course Name     :";
                     echo " " .$row['Course_name']. "  ";echo "<br>";
                     echo "<a href='#' style='text-decoration:none;color:#FF8000' >View marks</a>";echo "<br>";
                     echo "<a href='#' style='text-decoration:none;color:#FF8000' >View Statistics</a>";echo "<br>";
                                         echo "<a href='#' style='text-decoration:none;color:#FF8000'>View performance goals</a>";echo "<br>";

                     echo "<br>";
                     echo "</div>";


             } echo "</table>";

?>

 <a href="#" style="text-decoration:none;color:lightgrey;text-align:center;"><h2>View all course marks</h2></a>

</div>

</body>
</html>
