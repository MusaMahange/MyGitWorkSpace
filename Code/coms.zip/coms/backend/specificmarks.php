	<?php
	session_start();
	include_once 'dbc.php';
	$email = $_SESSION['email'];
	$course = mysqli_real_escape_string($link,$_POST['course']);
	$assessment = mysqli_real_escape_string($link,$_POST['assessment']);
	
	$sql= "SELECT * FROM marks WHERE email_adress = '$email' AND course = '$course' AND assessment_name= '$assessment';";
	$result = mysqli_query($link,$sql);
	$array = mysqli_fetch_assoc($result);
	$checkResult = mysqli_num_rows($result);
	if($checkResult<1){
		$_SESSION['specific']=false;
		header("Location: ../home1.php?");
		exit();
	}
	echo "<table border=1>
	<tr>
	<th>email_adress</th>
	<th>mark</th>
	<th>assessment_name</th>
	<th>course</th>
	</tr>";

	echo "<tr>";
	echo "<td>" . $array['email_adress'] . "</td>";
	echo "<td>" . $array['mark']. "</td>";
	echo "<td>" . $array['assessment_name'] . "</td>";
	echo "<td>" . $array['course'] . "</td>";
	echo "<tr>";
	echo "</table>";
	