<?php
session_start();
if(isset($_POST['submit'])){
	include 'dbc.php';
	
	$email_adress = mysqli_real_escape_string($link, $_POST['email_adress']);
	$password = mysqli_real_escape_string($link, $_POST['password']);
	//echo'hey';
	//check if fields are empty
	
	if(empty($email_adress)||empty($password)){
		header("Location: ../index.php?login=error1");
		exit();		
	}
	else{
		$sql="SELECT * FROM users where email_adress='$email_adress'";
		$result = mysqli_query($link,$sql);
		$checkResult = mysqli_num_rows($result);
		if($checkResult<1){
			header("Location: ../index.php?login=not registered");
			exit();
		}
		else{
			if($array = mysqli_fetch_assoc($result)){
				
				$verifypwd = password_verify($password, $array['password']);
				if($verifypwd==false){
					header("Location: ../index.php?login=error2");
					exit();	
				}
				else{
					$_SESSION['email']= $array['email_adress'];
					$_SESSION['name']= $array['first_name'];
					$_SESSION['surname']= $array['last_name'];
					$_SESSION['occupation']= $array['occupation'];
					$_SESSION['school']= $array['school'];
					$_SESSION['password']= $array['password'];
					// put code that sends the user to the home page
					if($_SESSION['occupation']=='course coordinator'){
						header("Location: ../home.php?login=logedin");
					}
					elseif($_SESSION['occupation']=='student'){
						header("Location: ../home1.php?login=logedin");
					}
					
					
				}
			}
		}
	}
}else{
	header("Location: ../index.php?login=error3");
	exit();
}