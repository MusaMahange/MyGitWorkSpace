<!DOCTYPE html>
<html lang="en">

	<?php
	session_start();
	include_once 'dbc.php';
	$email = $_SESSION['email'];
	$sql="SELECT * FROM marks WHERE email_adress = '$email';";
	$result = mysqli_query($link,$sql);
	echo "<table border=1>
	<tr>
	<th>email_adress</th>
	<th>mark</th>
	<th>assessment_name</th>
	<th>course</th>
	</tr>";
	while($array = mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>" . $array['email_adress'] . "</td>";
		echo "<td>" . $array['mark']. "</td>";
		echo "<td>" . $array['assessment_name'] . "</td>";
		echo "<td>" . $array['course'] . "</td>";
		echo "<tr>";
	}
	echo "</table>";
	//where email_adress='$email_adress' AND assessment_name='$assessment AND course='course'";
	/*echo'</br>';
	echo "<table border=1>
	<tr>
	<th>minimum mark</th>
	<th>highest mark</th>
	<th>average mark</th>
	</tr>";
	$sql="SELECT MIN(mark) FROM marks";
	$result = mysqli_fetch_assoc(mysqli_query($link,$sql));
	$sql="SELECT MAX(mark) FROM marks";
	$result2 = mysqli_fetch_assoc(mysqli_query($link,$sql));
	$sql="SELECT AVG(mark) FROM marks";
	$result3 = mysqli_fetch_assoc(mysqli_query($link,$sql));
	echo "<tr>";
	echo "<td>" . $result['MIN(mark)'] . "</td>";
	echo "<td>" . $result2['MAX(mark)'] . "</td>";
	echo "<td>" . $result3['AVG(mark)'] . "</td>";
	echo "<tr>";
	echo "</table>";*/


?>
<style>
body{
background-image:url('../bg.png');
}
</style>

</html>	
	



