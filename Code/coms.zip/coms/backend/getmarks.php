<html>
<?php

session_start();
if(isset($_POST['submit'])){
	include_once 'dbc.php';
	//$course = mysqli_real_escape_string($link,$_POST['course']);
	//$assessment = mysqli_real_escape_string($link, $_POST['assessment_name']); // in the background coms3test1 maybe should put course post,maybe not.
	//$email_adress = $_SESSION['email'];
	$sql="SELECT * FROM marks";
	$result = mysqli_query($link,$sql);
	$checkResult = mysqli_num_rows($result);
	if($checkResult<1){
		$_SESSION['specific']=false;
		header("Location: ../home.php?login=not registered");
		exit();
		
	}
	
	
	//print according to html
	echo "<table border=1>
	<tr>
	<th>email_adress</th>
	<th>mark</th>
	<th>assessment_name</th>
	<th>course</th>
	</tr>";
	while($array = mysqli_fetch_assoc($result)){
		echo "<tr>";
		echo "<td>" . $array['email_adress'] . "</td>";
		echo "<td>" . $array['mark']. "</td>";
		echo "<td>" . $array['assessment_name'] . "</td>";
		echo "<td>" . $array['course'] . "</td>";
		echo "<tr>";
	}
	echo "</table>";
	//where email_adress='$email_adress' AND assessment_name='$assessment AND course='course'";
	echo'</br>';
	echo "<table border=1>
	<tr>
	<th>minimum mark</th>
	<th>highest mark</th>
	<th>average mark</th>
	</tr>";
	$sql="SELECT MIN(mark) FROM marks";
	$result = mysqli_fetch_assoc(mysqli_query($link,$sql));
	$sql="SELECT MAX(mark) FROM marks";
	$result2 = mysqli_fetch_assoc(mysqli_query($link,$sql));
	$sql="SELECT AVG(mark) FROM marks";
	$result3 = mysqli_fetch_assoc(mysqli_query($link,$sql));
	echo "<tr>";
	echo "<td>" . $result['MIN(mark)'] . "</td>";
	echo "<td>" . $result2['MAX(mark)'] . "</td>";
	echo "<td>" . $result3['AVG(mark)'] . "</td>";
	echo "<tr>";
	echo "</table>";

}
?>
</html>