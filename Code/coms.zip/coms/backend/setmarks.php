<?php

if(isset($_POST['submit'])){
	include_once 'dbc.php';
	
	$email = mysqli_real_escape_string($link, $_POST['email_adress']);
	$mark = mysqli_real_escape_string($link, $_POST['mark']);
	$assessment = mysqli_real_escape_string($link, $_POST['assessment_name']);
	$course = mysqli_real_escape_string($link, $_POST['course']);
	$weighting= mysqli_real_escape_string($link, $_POST['weighting']);
	$total = mysqli_real_escape_string($link, $_POST['total']);
	
	//checks if not duplicating the same mark in the database
	$sql="SELECT * FROM marks WHERE email_adress='$email' AND assessment_name='$assessment' AND  course='$course'"; 
	$result = mysqli_query($link,$sql);
	$checkResult = mysqli_num_rows($result);
	if($checkResult>0){
		header("Location: ../home.php?");
		exit();
	}
	//puts data in the marks table
	$sql="INSERT INTO marks(email_adress, mark, assessment_name, course) 
	VALUES ('$email', '$mark', '$assessment','$course');";
	mysqli_query($link,$sql);
	
	
	//puts data in the info table
	$sql="INSERT INTO info(course, assessment_name, weighting, total) 
	VALUES ('$course', '$assessment','$weighting','$total');";
	mysqli_query($link,$sql);
	header("Location: ../home.php?");
	//echo'data successfuly added';
}
else{
	header("Location: ../home.php?add=usefields");
	
}
