<?php
//connects with the database
$Server="localhost";
$username="root";
$dbpassword="";
$dbname="project";

$link = mysqli_connect($Server,$username,$dbpassword,$dbname);