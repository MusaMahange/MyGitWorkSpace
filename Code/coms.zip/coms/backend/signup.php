<?php

if(isset($_POST['submit'])){
	include_once 'dbc.php';
	
	$first_name = mysqli_real_escape_string($link, $_POST['first_name']);
	$last_name = mysqli_real_escape_string($link, $_POST['last_name']);
	$email_adress = mysqli_real_escape_string($link, $_POST['email_adress']);
	$school = mysqli_real_escape_string($link, $_POST['school']);
	$occupation = mysqli_real_escape_string($link, $_POST['occupation']);
	$password = mysqli_real_escape_string($link, $_POST['password']);
	
	//check if any field is empty
	if(empty($first_name)||empty($last_name)||empty($email_adress)||empty($school)||empty($occupation)||empty($password)){
		header("Location: ../index.php?signup=empty");
		exit();
	}
	else{
		//checks if email  is valid
		if(!filter_var($email_adress, FILTER_VALIDATE_EMAIL)){
			header("Location: ../index.php?index=invalid email");
			exit();
		}
		else{
			$sql="SELECT * FROM users where email_adress='$email_adress'";
			$result = mysqli_query($link,$sql);
			$checkResult = mysqli_num_rows($result);
			
			if($checkResult>0){
				header("Location: ../index.php?signup=usertaken");
				exit();
			}else{
				//encryptin the password
				$secretPwd = password_hash($password, PASSWORD_DEFAULT);
				//INSERT DATA IN DATABASE
				$sql = "INSERT INTO users (email_adress, first_name,last_name, school,occupation,password) VALUES ('$email_adress',
				'$first_name','$last_name','$school','$occupation','$secretPwd');";
				mysqli_query($link,$sql);
				header("Location: ../index.php?signup=success");
				exit();
			}
		}
	}
}
else{
	header("Location: ../index.php?signup=couldn't find post");
}
	
	
	
