<html>
<head>

</head>
<body>
<?php
session_start();
include 'backend/dbc.php';

echo'<h2> you are logged in as student</h2>';
echo '</br>';
echo'welcome'.' '. $_SESSION['name'];
echo '</br>';

if($_SESSION['specific']=true){
	echo "<font color='red'>there is no data for this query</font>";
	
}
?>
<form action="backend/specificmarks.php" method="POST"> 
		<input type="text" name="course" placeholder="course">
		<input type="text" name="assessment" placeholder="Assessment name">
	<button type='submit' name='submit'>view specific mark</button>
</form>

<form action="backend/studentmarks.php" method="POST"> 
	<button type='submit' name='submit'>view all marks </button>
</form>

<style>
body{
background-image:url('bg.png');
}
</style>
</body>


</html>