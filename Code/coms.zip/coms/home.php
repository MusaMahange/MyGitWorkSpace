<!DOCTYPE html>
<html>
<?PHP
session_start();
include 'backend/dbc.php';
if($_SESSION['occupation']=="course coordinator"){
	echo'<h1> course coordinator</h1>';
	echo '</br>';
	echo'welcome'.' '. $_SESSION['name'];
	
}
elseif($_SESSION['occupation']=="student"){
	header("Location: ../home1.php?index=invalid email");
	exit();
}
else{
	header("Location: ../home2.php?index=invalid email");
	exit();
}
?>
<style>
body{
background-image:url('bg.png');
}
</style>


<h1> add marks </h1>
<form action="backend/setmarks.php" method="POST">
<input type ="text" name="email_adress" placeholder="email">
<input type ="text" name="mark" placeholder="mark">
<input type ="text" name="assessment_name" placeholder="asessment_name">
<input type ="text" name="course" placeholder="course">
<input type ="text" name="weighting" placeholder="weighting">
<input type ="text" name="total" placeholder="out of">
<button type="submit" name="submit">ADD</button>
</form>
<form action="backend/getmarks.php" method="POST">
<button type="submit" name="submit"> get marks </button>
</form>
	
	


</html>