<!DOCTYPE html>
<html lang="en">
<head>
<title>Record management system</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="style.css">
<link rel="stylesheet" type="text/css" media="screen" href="slider.css">
<link href='http://fonts.googleapis.com/css?family=Cabin+Sketch:400,700' rel='stylesheet' type='text/css'>
<script src="jquery-1.7.min.js"></script>
<script src="jquery.easing.1.3.js"></script>
<script src="tms-0.4.1.js"></script>
<script>
$(document)
    .ready(function () {
    $('.slider')
        ._TMS({
        show: 0,
        pauseOnHover: true,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true,
        pagNums: false,
        slideshow: 7000,
        numStatus: false,
        banners: false,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">

<![endif]-->
<style>
body{
background-image:url('bg.png');
}
</style>


</head>
<body >
<div class="main">
  <!--==============================header=================================-->
  <header>
    <h1><a href="index.html"><img src="dsaf/logo.png" alt=""></a></h1>
    <nav>
      <div id="slide">
        <div class="slider">
          <ul class="items">
            <li><img src="s1.jpg" alt=""></li>

            <li><img src="s3.jpg" alt=""></li>
          </ul>
        </div>
        <a href="#" class="prev"></a><a href="#" class="next"></a> </div>
      <ul class="menu">
        <li class="current"><a href="index.html" class="clr-1">Home</a></li>
        <li><a href="contact.html" class="clr-2">Contact</a></li>
        <li><a href="help.html" class="clr-3">Help</a></li>
        <li><a href="signin.html" class="clr-4">Login</a></li>
        <li><a href="signup.html" class="clr-5">Register</a></li>
      </ul>
    </nav>
  </header>
  <!--==============================content================================-->
</div>
</body>
</html>
