<?php
$servername = "localhost";
$username = "f3844563_mushe";
$password = "ITmudzanani1";
$dbname = "f3844563_Employees";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
//register
$Name = $_POST["name"];
$Surname =$_POST["surname"];
$Email =$_POST["email"];
$nameofschool=$_POST["nameofschool"];
$Occupation =$_POST["occupation"];
$Password =$_POST["password"];
$ConfPass =$_POST["confirmpassword"];

//login check
$UserEmail =$_POST["email"];
$UserPass =$_POST["password"];


if($conn->connect_error){
  echo "Not connected";
}
else{
    //For register
	 if(isset($_POST["register"])){
		  if( $Password == $ConfPass)
						  {


						 $check = mysqli_query($conn,"SELECT Reg_email FROM Register WHERE Reg_email='$Email'");
						  if (mysqli_num_rows($check) > 0)
						  {
							echo "<script>alert('User already exit, Sign in')</script>";
						  }
						  else
						  {
					     $query = "INSERT INTO Register(Reg_name,Reg_surname,Reg_email,Reg_school,Reg_occupation,Reg_password)VALUES ('$Name','$Surname','$Email','$nameofschool','$Occupation', '$Password')";
	                          if($conn->query($query) == true)
								{
								  if($Occupation == 'student')
								  {

                      $q = "INSERT INTO Student(Student_name,Student_surname,Student_email,Student_school)VALUES ('$Name','$Surname','$Email','$nameofschool')";
                          if($conn->query($q) == true){
                              header('Location:student.php');
                          }



								  }else if($Occupation == 'admin')
								  {
                    $q = "INSERT INTO Admin(Admin_name,Admin_surname,Admin_email,Admin_school)VALUES ('$Name','$Surname','$Email','$nameofschool')";
                        if($conn->query($q) == true){
                            header('Location:admin.html');
                        }

								  }else if($Occupation =='coordinator') {

                    $q = "INSERT INTO Coordinator(Coordinator_name,Coordinator_surname,Coordinator_email,Coordinator_school)VALUES ('$Name','$Surname','$Email','$nameofschool')";
                        if($conn->query($q) == true){
                            header('Location:coordinator.php');
                        }
								  }
								}
								else
								{
									echo "Error:" .$query ."<br>" .$conn->error;
								}

						  }

	                    }else {


			           	echo "<script>alert('password and cornfirm password does not match')</script>";

			          }

	    }
		//for login
	       if(isset($_POST["login"])){
				 $check = mysqli_query($conn,"SELECT Reg_occupation FROM Register WHERE Reg_email='$UserEmail' AND Reg_password ='$UserPass'");
			      if (mysqli_num_rows($check) > 0 )
					{

			  $sql = "Select Reg_occupation From Register WHERE Reg_email='$UserEmail'";
               $sqldata = mysqli_query($conn,$sql) or die('Error getting what what');

                  if($row = mysqli_fetch_array($sqldata,MYSQLI_ASSOC)) {
						 if($row['Reg_occupation'] == 'student')
						 {
						header('Location:student.php');

						 }else if($row['Reg_occupation']== 'admin')
						{
						header('Location:admin.php');

					       }else if($row['Reg_occupation'] =='coordinator') {

					      header('Location:coordinator.php');
				          }

				      }

					}else{	echo "<script>alert('User not found, Sign up please')</script>";
						 header('Location:signup.html');


					}


		 }

    }

?>
